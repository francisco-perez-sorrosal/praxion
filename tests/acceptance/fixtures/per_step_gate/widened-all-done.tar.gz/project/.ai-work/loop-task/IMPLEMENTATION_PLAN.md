# Plan: loop widget

## Goal

Build the loop widget one step at a time (plan goal 53).

## Steps

### Step 1: Write the widget

**Assignee**: implementer
**Implementation**: Write `src/step_1.py` so that `value()` returns the step id.
**Files**: `src/step_1.py`, `tests/test_step_1.py`, `bench/pyproject.toml`
**Check**: `/Users/fperez/dev/praxion/.claude/worktrees/per-step-gate/.venv/bin/python -m pytest tests/test_step_1.py -q -p no:cacheprovider` expects pass=1 fail=0 skip=0
**Done when**: `tests/test_step_1.py` passes.
