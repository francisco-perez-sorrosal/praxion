Task slug: loop-task
Spawn request: s2-a1-implement
You are implementing Step 2 of IMPLEMENTATION_PLAN.md, attempt 1 of 2.

<step id="2">
### Step 2: Write the widget

**Assignee**: implementer
**Implementation**: Write `src/step_2.py` so that `value()` returns the step id.
**Files**: `src/step_2.py`, `tests/test_step_2.py`
**Check**: `/Users/fperez/dev/praxion/.claude/worktrees/per-step-gate/.venv/bin/python -m pytest tests/test_step_2.py -q -p no:cacheprovider` expects pass=1 fail=0 skip=0
**Done when**: `tests/test_step_2.py` passes.
</step>

<health-guards source="TASK_BRIEF.md § Health Guards">
- [ ] Every widget module stays importable without side effects (brief guard 41).
</health-guards>

<finish>
1. Record a `## Step 2` section in /private/var/folders/x5/pt_h187j3px6_b1dh6fc74kr0000gn/T/tmp65qahfrx/project/.ai-work/loop-task/TEST_RESULTS.md ending with your Check: Result: line.
2. Flip only Step 2's line in /private/var/folders/x5/pt_h187j3px6_b1dh6fc74kr0000gn/T/tmp65qahfrx/project/.ai-work/loop-task/WIP.md; never edit an Attempts: or Check: line.
3. Stop in a committable state and never commit: the step-loop driver commits once it verifies.
   The driver runs the derived test scope at its gate once you return; start no scope yourself.
   Run the step's Check in the foreground and finish it before you return.
4. End with at most 5 lines whose last line is one marker: [COMPLETE], [BLOCKED] (add a Spec
   Question if a due outer-loop test contradicts the spec), [CONFLICT] or [PARTIAL].
</finish>
