# Task Brief: loop widget

## Task Intent

The loop widget exists so the acceptance suite can drive a plan (brief intent 29).

## Key Signals

- [ ] S1 — each widget module returns its step id.

## Health Guards

- [ ] Every widget module stays importable without side effects (brief guard 41).

## Uncertainty Flag

8/10 — none.
