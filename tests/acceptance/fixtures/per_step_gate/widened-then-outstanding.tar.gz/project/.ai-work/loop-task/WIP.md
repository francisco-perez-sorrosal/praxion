# WIP: loop widget

## Current Step

Step 1 of 2: Write the widget

## Status

[IN-PROGRESS] - Step underway

## Progress

- [x] Step 1: Write the widget
  - Attempts: Step 1 count=1 request=s1-a1-implement
- [ ] Step 2: Write the widget
  - Attempts: Step 2 count=1 request=s2-a1-implement

## Blockers

None
