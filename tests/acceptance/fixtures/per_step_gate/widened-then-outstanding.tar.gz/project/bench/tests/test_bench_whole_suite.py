def test_whole_suite_passes():
    assert True
