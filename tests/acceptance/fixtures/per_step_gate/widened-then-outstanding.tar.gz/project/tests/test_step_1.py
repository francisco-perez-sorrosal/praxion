from src.step_1 import value


def test_value_is_the_step_id():
    assert value() == '1'
