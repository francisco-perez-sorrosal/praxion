# HANDOFF: loop-task

slug: loop-task
boundary: mid-phase:attempts-exhausted
branch: master
base_sha: 6a7de870c0cbf53fd6d68cdfd2f9bef108398b8f
worktree_path: /private/var/folders/x5/pt_h187j3px6_b1dh6fc74kr0000gn/T/tmp5bnog9y1/project
composed_at: 2026-11-16T17:33:15Z
composer_version: 1
readiness: overridden

## §0 Preflight

Run these first. Each line is the command and the value to expect.

- `git status --porcelain` — expect empty. A dirty tree is work no diff against the base will show you.
- `git rev-parse --abbrev-ref HEAD` — expect `master`.
- `git merge-base HEAD <default-branch>` — expect `6a7de870c0cbf53fd6d68cdfd2f9bef108398b8f`. §1's position is diffed against that fork point, not against HEAD.
- `python3 scripts/reconcile_pipeline_state.py loop-task --json` — the authority on position. This document is not.
- The project's own test command — expect the baseline recorded in `.ai-work/loop-task/TEST_BASELINE.md`, when one exists.

## §1 State

- Worktree `/private/var/folders/x5/pt_h187j3px6_b1dh6fc74kr0000gn/T/tmp5bnog9y1/project`, branch `master` at `6a7de870c0cbf53fd6d68cdfd2f9bef108398b8f`.
- Artifacts present: `IMPLEMENTATION_PLAN.md`, `PROMPT_s1-a1-implement.md`, `PROMPT_s1-a2-implement.md`, `TASK_BRIEF.md`, `TEST_RESULTS.md`, `WIP.md`.
- Composed with `--force` over a non-quiescent tree. Conditions still firing: wal-unreadable, dirty-step-files. Re-derive this section from ground truth before trusting it.
- Position, from the reconciler (Tier-1 ground truth, not the checkbox):
  - `Step 1` — attempts-exhausted — 2 fresh attempt(s) used (cap 2) without verified completion; replan requested: attempt 1: completed; Result: pass=0 fail=1 skip=0 pending=0 by=step-loop; no commit | attempt 2: completed; Result: pass=0 fail=1 skip=0 pending=0 by=step-loop; no commit; underlying verdict mismatch: WIP=[COMPLETE] but check unmet: pass=: expected =1, observed 0; fail=: expected =0, observed 1

## §2 Next action

The step-loop driver stopped at `Step 1`: attempts-exhausted (exit 2).
2 of 2 fresh attempts at Step 1 ended unverified
- attempt 1 · agent a8aa80575e205435 · completed 12/100 · Result: pass=0 fail=1 skip=0 pending=0 by=step-loop · no commit
- attempt 2 · agent a20128ca8869f45d · completed 12/100 · Result: pass=0 fail=1 skip=0 pending=0 by=step-loop · no commit
Human decision owed: revise the step block (split it, or fix its Check: line).
Then resume the loop: `/praxion:step-loop loop-task` (it runs `python3 scripts/step_loop.py next loop-task`).

## §3 Decisions & assumptions in force

_[to fill at the checkpoint]_

## §4 Operating constraints from the user

_[to fill at the checkpoint]_

## §5 Corrections in force

_[to fill at the checkpoint]_

## §6 Do not re-inherit

_[to fill at the checkpoint]_

## §7 Start here

1. Run §0 Preflight and reconcile what it reports against §1.
2. Read §4–§6 before acting — the user's standing instructions, carried unchanged.
3. /resume-pipeline loop-task

