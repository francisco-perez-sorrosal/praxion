def value():
    return None
