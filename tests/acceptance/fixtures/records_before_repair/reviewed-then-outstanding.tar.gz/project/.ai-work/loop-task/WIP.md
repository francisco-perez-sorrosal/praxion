# WIP: loop widget

## Current Step

Step 1 of 3: Write the widget

## Status

[IN-PROGRESS] - Step underway

## Progress

- [x] Step 1: Write the widget
  - Attempts: Step 1 count=1 request=s1-a1-review-r2
- [x] Step 2: Write the widget
  - Attempts: Step 2 count=2 request=s2-a2-implement
- [ ] Step 3: Write the widget

## Blockers

None
